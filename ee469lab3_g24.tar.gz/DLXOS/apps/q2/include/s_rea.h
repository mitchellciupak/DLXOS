#include "shared.h"

#define S_REA_FILE "s_rea.dlx.obj"