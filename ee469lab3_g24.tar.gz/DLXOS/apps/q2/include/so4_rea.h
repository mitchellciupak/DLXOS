#include "shared.h"

#define SO4_REA_FILE "so4_rea.dlx.obj"