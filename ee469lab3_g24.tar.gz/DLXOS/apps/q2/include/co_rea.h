#include "shared.h"

#define CO_REA_FILE "co_rea.dlx.obj"