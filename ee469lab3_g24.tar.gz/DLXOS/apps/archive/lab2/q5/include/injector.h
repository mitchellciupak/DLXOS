#include "shared.h"

#define INJECTOR_FILE "injector.dlx.obj"