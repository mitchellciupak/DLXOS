#include "shared.h"

#define CO_INJ_FILE "co_inj.dlx.obj"