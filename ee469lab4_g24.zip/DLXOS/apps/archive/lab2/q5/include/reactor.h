#include "shared.h"

#define REACTOR_FILE "reactor.dlx.obj"