#ifndef __USERPROG__
#define __USERPROG__

typedef struct missile_code {
  int numprocs;
  char really_important_char;
} missile_code;

#define FILENAME_TO_RUN "cond_spawn.dlx.obj"

#endif
