#include "shared.h"

#define CONSUMER_FILE "consumer.dlx.obj"