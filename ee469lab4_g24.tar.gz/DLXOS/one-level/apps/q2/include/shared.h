#ifndef SHARED_H
#define SHARED_H

#define P1_FILE "p1.dlx.obj"
#define P2_FILE "p2.dlx.obj"
#define P3_FILE "p3.dlx.obj"
#define P4_FILE "p4.dlx.obj"
#define P6_FILE "p6.dlx.obj"
#endif