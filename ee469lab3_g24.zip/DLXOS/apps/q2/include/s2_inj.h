#include "shared.h"

#define S2_INJ_FILE "s2_inj.dlx.obj"