#include "shared.h"

#define PRODUCER_FILE "producer.dlx.obj"